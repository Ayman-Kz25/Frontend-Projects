document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".nav");

  navToggle.addEventListener("click", function () {
    navMenu.classList.toggle("nav-open");
  });
  const navLinks = document.querySelectorAll(".nav a");
  navLinks.forEach((link) => {
    link.addEventListener("click", function () {
      navMenu.classList.remove("nav-open");
    });
  });
  const form = document.querySelector(".contact-form");
  form.addEventListener("submit", function (event) {
    event.preventDefault();
    alert("Thank you for your message!");
    form.reset();
  });
});

document.addEventListener("DOMContentLoaded", function () {
  // Nav toggle code
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".nav");

  navToggle.addEventListener("click", function () {
    navMenu.classList.toggle("active");
  });

  document.addEventListener("click", (e) => {
    if (!nav.contains(e.target) && !navToggle.contains(e.target)) {
      nav.classList.remove("active");
    }
  });

  const navLinks = document.querySelectorAll(".nav a");
  navLinks.forEach((link) => {
    link.addEventListener("click", function () {
      navMenu.classList.remove("active");
    });
  });

  const form = document.querySelector(".contact-form");
  form.addEventListener("submit", function (event) {
    event.preventDefault();
    alert("Thank you for your message!");
    form.reset();
  });

  // Theme toggle code
  const themeToggle = document.getElementById("theme-toggle");
  const themeIcon = document.getElementById("theme-icon");

  themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");

    if (document.body.classList.contains("dark-mode")) {
      console.log("Dark mode enabled");
      themeIcon.classList.remove("fa-moon");
      themeIcon.classList.add("fa-sun");
    } else {
      console.log("Light mode enabled");
      themeIcon.classList.remove("fa-sun");
      themeIcon.classList.add("fa-moon");
    }
  });
});
